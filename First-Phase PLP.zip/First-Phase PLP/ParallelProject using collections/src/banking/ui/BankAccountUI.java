package banking.ui;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import banking.bean.BankAccount;
import banking.bean.Transaction;
import banking.service.BankAccountService;
import banking.service.BankAccountServiceImpl;

public class BankAccountUI {
	static Scanner scanner = new Scanner(System.in);
	static BankAccountService service = new BankAccountServiceImpl();

	public static void main(String args[]) {
		do {
			System.out.println("Welcome to Bank");
			System.out.println("1.Create Account");
			System.out.println("2.Show Balance");
			System.out.println("3.Deposit");
			System.out.println("4.Withdraw");
			System.out.println("5.Fund Transfer");
			System.out.println("6.Print Transactions");
			System.out.println("7.Exit");
			System.out.println("Enter your choice:");
			int choice = scanner.nextInt();
			switch (choice) {
			case 1:
				createAccount();
				break;
			case 2:
				showBalance();
				break;
			case 3:
				deposit();
				break;
			case 4:
				withdraw();
				break;
			case 5:
				fundTransfer();
				break;
			case 6:
				printTransactions();
				break;
			case 7:
				System.out.println("Do you want to exit:yes/no ");
				String ch = scanner.next();
				if (ch.toUpperCase().equals("YES"))
					System.exit(choice);
				break;
			default:
				System.out.println("You entered wrong input");
				System.out.println("Do you want to exit:yes/no ");
				String ch1 = scanner.next();
				if (ch1.toUpperCase().equals("YES"))
					System.exit(choice);
				break;
			}
		} while (true);
	}

	private static void printTransactions() {
		// TODO Auto-generated method stub
	     Map<Integer,Transaction>  map = service.printTransactions();
		for (Map.Entry<Integer,Transaction> entry : map.entrySet()) {
			Integer key = entry.getKey();
			Transaction value = entry.getValue();
			System.out.println("Account-Id : " + key + " " +"Account-Balance:"+ value);
		}
		// System.out.println(map);
		// System.out.println("InitialBalance="map.getKey()+"
		// "+"CurrentBalance="+map.getValue());

	}

	private static void fundTransfer() {
		// TODO Auto-generated method stub
		System.out.println("Enter from account you want to transfer:");
		int accNo1 = scanner.nextInt();
		System.out.println("Enter to which account you want to transfer:");
		int accNo2 = scanner.nextInt();
		System.out.println("Enter the amount");
		long amount = scanner.nextLong();
		service.fundTransfer(accNo1, accNo2, amount);
	}

	private static void withdraw() {
		// TODO Auto-generated method stub
		System.out.println("Enter from account you want to withdraw:");
		int accNo = scanner.nextInt();
		System.out.println("Enter the amount you want to withdraw:");
		long amount = scanner.nextLong();
		service.withdraw(accNo, amount);

	}

	private static void deposit() {
		// TODO Auto-generated method stub
		System.out.println("Enter the account you want to deposit:");
		int accNo = scanner.nextInt();
		System.out.println("Enter the amount you want to deposit:");
		long amount = scanner.nextLong();
		service.deposit(accNo, amount);

	}

	private static void showBalance() {
		// TODO Auto-generated method stub
		System.out.println("Enter accountNo");
		int accNo = scanner.nextInt();
		double balance = service.displayBalance(accNo);
		if(balance!=0.0)
		System.out.println(balance);

	}

	private static void createAccount() {
		// TODO Auto-generated method stub
		long phoneNo;
		long minBal;
		System.out.println("enter account holder name");
		String accName = scanner.next();
		boolean name = matches(accName);
		if (name == false) {
			System.err.println("Names must contain alphabets\n");
			return;
		}
		System.out.println("Enter phoneno");
		String phone = scanner.next();
		boolean number = matchPhoneNo(phone);
		if (number == false) {
			System.err.println("Phoneno must be valid\n");
			return;
		} else
			phoneNo = Long.parseLong(phone);
		System.out.println("Enter Initial balance");
		String balance = scanner.next();
		boolean bal = matchBalance(balance);
		if (bal == false) {
			System.err.println("Balance must contain digits\n");
			return;
		} else
			minBal = Long.parseLong(balance);
		BankAccount bankaccount = new BankAccount(accName, phoneNo, minBal);
		// System.out.println(bankaccount);
		service.CreateAccount(bankaccount);
	}

	private static boolean matchBalance(String balance) {
		// TODO Auto-generated method stub
		return balance.matches("[0-9]+");
	}

	private static boolean matchPhoneNo(String phoneNo) {
		// TODO Auto-generated method stub

		return phoneNo.matches("\\d{10}");
	}

	public static boolean matches(String name) {
		return name.matches("[A-Z][a-z]*");

	}
}
package banking.service;

import java.util.Collection;
import java.util.Map;

import banking.bean.BankAccount;
import banking.bean.Transaction;
import banking.dao.BankAccountDaoImpl;

public class BankAccountServiceImpl implements BankAccountService{
    static BankAccountDaoImpl dao=new BankAccountDaoImpl();
	@Override
	public void CreateAccount(BankAccount bankaccount) {
		// TODO Auto-generated method stub
		dao.CreateAccount(bankaccount);
	}
	@Override
	public double displayBalance(int accountNo) {
		// TODO Auto-generated method stub
		return dao.displayBalance(accountNo);
	}
	@Override
	public void deposit(int accountNo, double amount) {
		// TODO Auto-generated method stub
		dao.deposit(accountNo, amount);
	}
	@Override
	public void withdraw(int accountNo, double amount) {
		// TODO Auto-generated method stub
		dao.withdraw(accountNo, amount);
	}
	@Override
	public void fundTransfer(int accountNo1, int accountNo2, double amount) {
		// TODO Auto-generated method stub
		dao.fundTransfer(accountNo1, accountNo2, amount);
	}
	@Override
	public Map<Integer,Transaction> printTransactions(){
		// TODO Auto-generated method stub
		return dao.printTransactions();
	}
	

}

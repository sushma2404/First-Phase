package banking.dao;

import java.util.Collection;
import java.util.Map;

import banking.bean.BankAccount;
import banking.bean.Transaction;

public interface BankAccountDao {
	public void CreateAccount(BankAccount bankaccount);
	public double displayBalance(int accountNo);
	public void deposit(int accountNo,double amount);
	public void withdraw(int accountNo,double amount);
	public void fundTransfer(int accountNo1,int accountNo2,double amount);
	public Map<Integer,Transaction> printTransactions();
}

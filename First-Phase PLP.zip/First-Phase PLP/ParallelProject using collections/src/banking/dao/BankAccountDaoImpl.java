package banking.dao;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import banking.bean.BankAccount;
import banking.bean.Transaction;
import banking.exception.InsufficientBalanceException;
import banking.exception.InvalidAccountException;

public class BankAccountDaoImpl implements BankAccountDao{
  static List<BankAccount> list=new ArrayList<BankAccount>();
  static HashMap<Integer,Transaction> map=new HashMap<Integer,Transaction>();
  static BankAccount account =new BankAccount();
	@Override
	public void CreateAccount(BankAccount bankaccount) {
		// TODO Auto-generated method stub
		list.add(bankaccount);
		System.out.println("Account Created");
	//	System.out.println("list data  "+list);
		
	}
	@Override
	public double displayBalance(int accountNo) {
		// TODO Auto-generated method stub
		double balance = 0;
		int count=0;
	  // System.out.println("show balance ");
	   for(int i=0;i<list.size();i++)
	   {
		   int k=list.get(i).getAccountNo();
		   if(k==accountNo)
		   {
			   count=1;
			   balance=list.get(i).getAccountBalance();
		   }
		   if(count==0)
		   { 
			   try {
				   throw new InvalidAccountException(accountNo);
			   }
			   catch (InvalidAccountException e) {
				// TODO: handle exception
				   System.err.println("Invalid account Number\n");
				  
			}
			   
		   }
		   
	   }
	 //  BankAccount account=list.get(accountNo);
	  // System.out.println(account);
	     return balance;//account.getAccountBalance();
	}
	@Override
	public void deposit(int accountNo, double amount) {
		// TODO Auto-generated method stub
		int count=0;
		double currBalance=0;
		//System.out.println("deposit");
		 for(int i=0;i<list.size();i++)
		   {
			   int k=list.get(i).getAccountNo();
			   if(k==accountNo)
			   {
				   count=1;
				   double balance=list.get(i).getAccountBalance();
				   currBalance=amount+balance;
				   list.get(i).setAccountBalance(currBalance);
			   }
		   }
		 if(count==0)
		   { 
			   try {
				   throw new InvalidAccountException(accountNo);
			   }
			   catch (InvalidAccountException e) {
				// TODO: handle exception
				   System.err.println("Invalid account Number\n");
				  
			}
			   
		   }
	}
	@Override
	public void withdraw(int accountNo, double amount) {
		// TODO Auto-generated method stub
		int count=0;
		//System.out.println("withdraw");
		double currBalance=0;
		 for(int i=0;i<list.size();i++)
		   {
			   int k=list.get(i).getAccountNo();
			   if(k==accountNo)
			   {
				   count=1;
				   double balance=list.get(i).getAccountBalance();
				   try {
					   currBalance=balance-amount;
					   if(currBalance<0)
					   {
						   currBalance=balance;
						   throw new InsufficientBalanceException(amount);
					   }
						  
				   }
				   catch(InsufficientBalanceException ex)
				   {
					   System.err.println("Insufficient amount");
				   }
				   list.get(i).setAccountBalance(currBalance);
			   }
		   }
		 if(count==0)
		   { 
			   try {
				   throw new InvalidAccountException(accountNo);
			   }
			   catch (InvalidAccountException e) {
				// TODO: handle exception
				   System.err.println("Invalid account Number\n");
				  
			}
			   
		   }
		 
	}
	@Override
	public void fundTransfer(int accountNo1, int accountNo2, double amount) {
		// TODO Auto-generated method stub
		int count=0;
		int count1=0;
		//System.out.println("fund transfer");
		double currBalance=0;
		for(int i=0;i<list.size();i++)
		{
			int k=list.get(i).getAccountNo();
			if(k==accountNo1)
			{
				count=1;
				double balance=list.get(i).getAccountBalance();
				try {
					   currBalance=balance-amount;
					   if(currBalance<0) { 
						   currBalance=balance;
						   throw new InsufficientBalanceException(amount);
					   }
						   
				   }
				   catch(InsufficientBalanceException ex)
				   {
					   System.err.println("Insufficient amount");
				   }
				
				list.get(i).setAccountBalance(currBalance);
			}
			else if(k==accountNo2)
			{
				count1=1;
				double balance=list.get(i).getAccountBalance();
				currBalance=balance+amount;
				list.get(i).setAccountBalance(currBalance);
			}
		}
		if(count1==0)
		   { 
			   try {
				   throw new InvalidAccountException(accountNo1);
			   }
			   catch (InvalidAccountException e) {
				// TODO: handle exception
				   System.err.println("Invalid account Number\n");
				  
			}
			   
		   }
		if(count1==0)
		   { 
			   try {
				   throw new InvalidAccountException(accountNo2);
			   }
			   catch (InvalidAccountException e) {
				// TODO: handle exception
				   System.err.println("Invalid account Number\n");
				  
			}
			   
		   }
	}
	@Override
	public Map<Integer,Transaction> printTransactions() {
		// TODO Auto-generated method stub
		for(int i=0;i<list.size();i++)
		{
			double initialBal=list.get(i).getInitialBalance();
			double finalBal=list.get(i).getAccountBalance();
			Transaction transaction=new Transaction(initialBal,finalBal);
			
			map.put(list.get(i).getAccountNo(), transaction);
		}
		return map;
	}

	
	
	
}

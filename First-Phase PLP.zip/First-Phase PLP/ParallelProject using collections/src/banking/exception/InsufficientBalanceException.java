package banking.exception;

public class InsufficientBalanceException extends Exception{
	public InsufficientBalanceException(double amount)
	{
		super();
	}

}

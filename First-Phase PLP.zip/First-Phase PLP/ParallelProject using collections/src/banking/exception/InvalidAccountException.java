package banking.exception;

public class InvalidAccountException extends Exception{


	public  InvalidAccountException(int id) {
		super();
	}

}

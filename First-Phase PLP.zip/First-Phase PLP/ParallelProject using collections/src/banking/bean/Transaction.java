package banking.bean;

public class Transaction {
	private double initialBalance;
	private double currentBalance;
	
	public Transaction(double initialBalance, double currentBalance) {
		super();
		this.initialBalance = initialBalance;
		this.currentBalance = currentBalance;
	}
	public double getInitialBalance() {
		return initialBalance;
	}
	public void setInitialBalance(double initialBalance) {
		this.initialBalance = initialBalance;
	}
	public double getCurrentBalance() {
		return currentBalance;
	}
	public void setCurrentBalance(double currentBalance) {
		this.currentBalance = currentBalance;
	}
	@Override
	public String toString() {
		return "[initialBalance=" + initialBalance + ", currentBalance=" + currentBalance + "]";
	}
	

}
